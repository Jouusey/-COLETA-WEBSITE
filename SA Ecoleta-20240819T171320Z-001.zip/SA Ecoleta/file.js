//* Variáveis que recebem os valores do html
let elementoInputNomeCadastro = document.getElementById('inptNomeCadastro')
let elementoInputSenhaCadastro = document.getElementById('inptSenhaCadastro')
let elementoInputEmailCadastro = document.getElementById('inptEmailCadastro')
let elementoInputTelefoneCadastro = document.getElementById('inptTelefoneCadastro')
let elementoInputFisicoJuridicoCadastro = document.getElementById('inptFisicoJuridicoCadastro')
let elementoLabelFisicoJuridicoCadastro = document.getElementById('lblFisicoJuridico')
let elementoButtonContaPessoal = document.getElementById('buttonContaPessoal')
let elementoButtonContaEmpresarial = document.getElementById('buttonContaEmpresarial')
let elementoAvisoNome = document.getElementById(`avisoNome`)
let elementoAvisoSenha = document.getElementById(`avisoSenha`)
let elementoAvisoEmail = document.getElementById(`avisoEmail`)
let elementoAvisoTelefone = document.getElementById(`avisoTelefone`)
let elementoAvisoFisicoJuridico = document.getElementById(`avisoFisicoJuridico`)

let elementoInputUsuarioLogin = document.getElementById('inptUsuarioLogin')
let elementoInputSenhaLogin = document.getElementById('inptSenhaLogin')

let elementoDivDadosPessoais = document.getElementById('dadosPessoais')
let elementoDivLixosDesejados = document.getElementById('lixosDesejados')
let elementoDivHistoricoLixo = document.getElementById('historicoLixo')
let elementoButtonDivDadosPessoais = document.getElementById('btnDadosPessoais')
let elementoButtonDivLixosDesejados = document.getElementById('btnLixosDesejados')
let elementoButtonDivHistoricoLixo = document.getElementById('btnHistoricoLixo')

let elementoInputNomePerfil = document.getElementById('inptUsuarioPerfil')
let elementoInputEmailPerfil = document.getElementById('inptEmailPerfil')
let elementoInputTelefonePerfil = document.getElementById('inptTelefonePerfil')
let elementoInputFisicoJuridicoPerfil = document.getElementById('inptFisicoJuridicoPerfil')
let elementoInputSenhaPerfil = document.getElementById('inptSenhaPerfil')
let elementoInputNovaSenhaPerfil = document.getElementById('inptNovaSenhaPerfil')
let elementoInputConfirmarSenhaPerfil = document.getElementById('inptConfirmarSenhaPerfil')
let elementoInputEnderecoPerfil = document.getElementById('inptEnderecoPerfil')

let elementoInputAdicionarLixo = document.getElementById('inptAdicionarLixo')
let elementoButtonTagUm = document.getElementById('btnTagUm')
let elementoButtonTagDois = document.getElementById('btnTagDois')
let elementoButtonTagTres = document.getElementById('btnTagTres')
let elementoButtonTagQuatro = document.getElementById('btnTagQuatro')
let elementoButtonTagCinco = document.getElementById('btnTagCinco')
let elementoButtonTagSeis = document.getElementById('btnTagSeis')

let elementoButtonRiscoTranquilo = document.getElementById('btnRiscoTranquilo')
let elementoButtonRiscoMedio = document.getElementById('btnRiscoMedio')
let elementoButtonRiscoMaior = document.getElementById('btnRiscoMaior')

let elementoLabelNomeLixosDesejadosUm = document.getElementById('lblNomeLixosDesejadosUm')
let elementoLabelNomeLixosDesejadosDois = document.getElementById('lblNomeLixosDesejadosDois')
let elementoLabelNomeLixosDesejadosTres = document.getElementById('lblNomeLixosDesejadosTres')
let elementoLabelNomeLixosDesejadosQuatro = document.getElementById('lblNomeLixosDesejadosQuatro')
let elementoLabelNomeLixosDesejadosCinco = document.getElementById('lblNomeLixosDesejadosCinco')
let elementoLabelTagsLixosDesejadosUm = document.getElementById('lblTagsLixosDesejadosUm')
let elementoLabelTagsLixosDesejadosDois = document.getElementById('lblTagsLixosDesejadosDois')
let elementoLabelTagsLixosDesejadosTres = document.getElementById('lblTagsLixosDesejadosTres')
let elementoLabelTagsLixosDesejadosQuatro = document.getElementById('lblTagsLixosDesejadosQuatro')
let elementoLabelTagsLixosDesejadosCinco = document.getElementById('lblTagsLixosDesejadosCinco')

let elementoCheckboxUm = document.getElementById('chckbxUm')
let elementoCheckboxDois = document.getElementById('chckbxDois')
let elementoCheckboxTres = document.getElementById('chckbxTres')
let elementoCheckboxQuatro = document.getElementById('chckbxQuatro')
let elementoCheckboxCinco = document.getElementById('chckbxCinco')

let elementoDivDireitaMeioMainPag = document.getElementById('divDireitaMeio')
let elementoDivDireitaBaixo = document.getElementById('divDireitaBaixo')
let elementoDivDireitaTopo = document.getElementById('divTopoButtons')
let elementoDivDireitaTopoPerfil = document.getElementById('divTopoButtonsPerfil')


////                                                                               ////
//*Variáveis Booleanas
let contaEmpresarial = false, contaPessoal = false
let usuarioLogado = false
let emailJaRegistrado = false, fisicoJuridicoJaRegistrado = false, fisicoJuridicoInvalido = false
let emailPerfilExistente = false
////                                                                               ////
//*Variáveis Vetores
let listaUsuarios = []
let separarNumerosFisicoJuridico = []
let tagsLixoDesejado = [false,false,false,false,false,false]
let vetorLixosDesejados = []
////                                                                               ////
//*Variáveis Objetos
let objUsuario = {

    nome: '',
    senha: '',
    email: '',
    telefone: '',
    fisicoJuridico: '',
    endereco: '',
    tipoConta:'',
    propLixosDesejados: ''

}

let objLixoDesejadoUsuario = {

    nomeLixoDesejado: '',
    propTagsLixosDesejados: '',
    nivelPerigo: ''


}

////                                                                               ////
//*Variáveis normais
let multiplicacaoFisicoJuridico, somaFisicoJuridico = 0, resultadoFisicoJuridico, contadorTags = 0
let j
let posicaoUsuarioLogado

////                                                                               ////


listaUsuarios = JSON.parse(localStorage.getItem('cadastroUsuario'))
usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'))
tagsLixoDesejado = JSON.parse(localStorage.getItem('tagsLixoDesejado'))
vetorLixosDesejados = JSON.parse(localStorage.getItem('vetorLixosDesejados'))


//? Inicio das funções de Cadastro e Login *exceto ValidarCPF/CNPJ*

function ReiniciarValores(){

    usuarioLogado = false
    emailJaRegistrado = false
    fisicoJuridicoJaRegistrado = false
    fisicoJuridicoInvalido = false
    somaFisicoJuridico = false

}

function ContaPessoal(){

    contaEmpresarial = false
    contaPessoal = true
    elementoLabelFisicoJuridicoCadastro.innerHTML = 'CPF&nbsp;'
    elementoButtonContaPessoal.classList.add('buttonAtivado')
    elementoButtonContaEmpresarial.classList.remove('buttonAtivado')

}

function ContaEmpresarial(){

    contaEmpresarial = true
    contaPessoal = false
    elementoButtonContaPessoal.classList.remove('buttonAtivado')
    elementoButtonContaEmpresarial.classList.add('buttonAtivado')
    elementoLabelFisicoJuridicoCadastro.innerHTML = 'CNPJ&nbsp;'
}

function VerificarCadastro(){

    ReiniciarValores()

    console.log(elementoInputFisicoJuridicoCadastro.value)

    if(listaUsuarios == null){

        listaUsuarios = []

    }

    if(contaEmpresarial != true && contaPessoal != true){

    

    }else if(elementoInputNomeCadastro.value == '' || elementoInputSenhaCadastro.value == '' || elementoInputEmailCadastro.value == '' || elementoInputTelefoneCadastro.value == '' || elementoInputFisicoJuridicoCadastro.value == '' ){

       
        
        if(elementoInputNomeCadastro.value == ''){

            elementoAvisoNome.innerHTML = `O nome esta vazio`

        }else{

        
            elementoAvisoNome.innerHTML = `...`


        }

        if(elementoInputSenhaCadastro.value == ''){

            elementoAvisoSenha.innerHTML = `A senha esta vazia`

        }else{

        
            elementoAvisoSenha.innerHTML = `...`


        }
                    

        if(elementoInputEmailCadastro.value == ''){

            elementoAvisoEmail.innerHTML = `O Email esta vazio`

        }else{

        
            elementoAvisoEmail.innerHTML = `...`


        }
                    

        if(elementoInputTelefoneCadastro.value == ''){

            elementoAvisoTelefone.innerHTML = `O telefone esta vazio`

        }else{

        
            elementoAvisoTelefone.innerHTML = `...`


        }
                    

        if(elementoInputFisicoJuridicoCadastro.value == ''){

            elementoAvisoFisicoJuridico.innerHTML = `O CPF/CNPJ esta vazio`

        }else{

            
            elementoAvisoFisicoJuridico.innerHTML = '...'

        
            elementoAvisoFisicoJuridico.innerHTML = `O CPF/CNPJ é invalido`


        }
            
            

    }else{



        for(i=0;i < listaUsuarios.length;i++){

            switch (true){

                case listaUsuarios[i].email == elementoInputEmailCadastro.value && listaUsuarios[i].fisicoJuridico != elementoInputFisicoJuridicoCadastro.value:

                    emailJaRegistrado = true
                    break;

                case listaUsuarios[i].email != elementoInputEmailCadastro.value && listaUsuarios[i].fisicoJuridico == elementoInputFisicoJuridicoCadastro.value:

                    fisicoJuridicoJaRegistrado = true
                    break;

                case listaUsuarios[i].email == elementoInputEmailCadastro.value && listaUsuarios[i].fisicoJuridico == elementoInputFisicoJuridicoCadastro.value:

                    emailJaRegistrado = true
                    fisicoJuridicoJaRegistrado = true
                    break;

                case listaUsuarios[i].email != elementoInputEmailCadastro.value && listaUsuarios[i].fisicoJuridico != elementoInputFisicoJuridicoCadastro.value:

                    console.log('passou na verificação do indice ' + i)
                    break;

            }


        }

        //todo: trocar os alerts para editar as labels das divs
        //? verificar se o usuário pode se cadastrar ou não
        switch (true){

            case emailJaRegistrado == true && fisicoJuridicoJaRegistrado == true:

                elementoAvisoEmail.innerHTML = `O Email já esta registrado`
                elementoAvisoEmail.innerHTML = `O CPF/CNPJ já esta registrado`

                
                break;
            case emailJaRegistrado == true:
                
                elementoAvisoEmail.innerHTML = `O Email já esta registrado`
                break;
            case fisicoJuridicoJaRegistrado == true:
                
                elementoAvisoEmail.innerHTML = `O CPF/CNPJ já esta registrado`
                break;
            default:
                ValidarCPFCNPJ()
            
        }


        if(emailJaRegistrado == false && fisicoJuridicoJaRegistrado == false && fisicoJuridicoInvalido == false){

            CadastrarUsuario()

        }else{


        }
    }
}

function CadastrarUsuario(){

    objUsuario = {}

    objUsuario.nome = elementoInputNomeCadastro.value
    objUsuario.senha = elementoInputSenhaCadastro.value 
    objUsuario.email = elementoInputEmailCadastro.value
    objUsuario.telefone = elementoInputTelefoneCadastro.value 
    objUsuario.fisicoJuridico = Number(elementoInputFisicoJuridicoCadastro.value)

    if(contaEmpresarial){

        objUsuario.tipoConta = 0

    }else if(contaPessoal){

        objUsuario.tipoConta = 1
    }

    
    listaUsuarios.push(objUsuario)
    localStorage.setItem('cadastroUsuario', JSON.stringify(listaUsuarios))

    usuarioLogado = true

    for(i=0;i <listaUsuarios.length;i++){

        if (elementoInputEmailCadastro.value == listaUsuarios[i].email){

            posicaoUsuarioLogado = i
            localStorage.setItem('posicaoUsuario', JSON.stringify(posicaoUsuarioLogado))
            localStorage.setItem('usuarioLogado', JSON.stringify(usuarioLogado))
            break

        }

    }

    window.location.href = 'perfilUsuario.html'

}

function VerificarLogin(){

    for(i=0; i < listaUsuarios.length;i++){

        if(elementoInputUsuarioLogin.value == listaUsuarios[i].email || elementoInputUsuarioLogin.value == listaUsuarios[i].fisicoJuridico){

            if(listaUsuarios[i].senha == elementoInputSenhaLogin.value){

                usuarioLogado = true
                window.location.href = 'perfilUsuario.html'
                posicaoUsuarioLogado = i
                localStorage.setItem('posicaoUsuario', JSON.stringify(posicaoUsuarioLogado))
                localStorage.setItem('usuarioLogado', JSON.stringify(usuarioLogado))
                i--
                break


            }else{

                
                elementoAvisoSenha.innerHTML = 'A senha esta incorreta.'

                i--
                break

            }

        }


    }

    if(i == listaUsuarios.length){

        
        
        elementoAvisoSenha.innerHTML = ''
        elementoAvisoEmail.innerHTML = 'Usuario não encontrado.'


    }


}

//? Fim das funções de Cadastro e Login *exceto ValidarCPF/CNPJ*


//? Início das funções de Dados Pessoais

function DadosPessoais(){

    elementoDivDadosPessoais.style.display = 'block'
    elementoDivLixosDesejados.style.display = 'none'
    elementoDivHistoricoLixo.style.display = 'none'


    elementoButtonDivDadosPessoais.classList.add('btnAtivado')
    elementoButtonDivLixosDesejados.classList.remove('btnAtivado')
    elementoButtonDivHistoricoLixo.classList.remove('btnAtivado')


}

function LixosDesejados(){

    elementoDivDadosPessoais.style.display = 'none'
    elementoDivLixosDesejados.style.display = 'block'
    elementoDivHistoricoLixo.style.display = 'none'
    elementoButtonDivDadosPessoais.classList.remove('btnAtivado')
    elementoButtonDivLixosDesejados.classList.add('btnAtivado')
    elementoButtonDivHistoricoLixo.classList.remove('btnAtivado')

}

function HistoricoLixo(){

    elementoDivDadosPessoais.style.display = 'none'
    elementoDivLixosDesejados.style.display = 'none'
    elementoDivHistoricoLixo.style.display = 'block'
    elementoButtonDivDadosPessoais.classList.remove('btnAtivado')
    elementoButtonDivLixosDesejados.classList.remove('btnAtivado')
    elementoButtonDivHistoricoLixo.classList.add('btnAtivado')

}

posicaoUsuarioLogado = JSON.parse(localStorage.getItem('posicaoUsuario'))

function CarregarPerfil(){

    if(usuarioLogado != true){

        window.location.href = 'login.html'

    }

    elementoInputNomePerfil.value = listaUsuarios[posicaoUsuarioLogado].nome
    elementoInputEmailPerfil.value = listaUsuarios[posicaoUsuarioLogado].email
    elementoInputTelefonePerfil.value = listaUsuarios[posicaoUsuarioLogado].telefone
    elementoInputFisicoJuridicoPerfil.value = listaUsuarios[posicaoUsuarioLogado].fisicoJuridico

    if(listaUsuarios[posicaoUsuarioLogado].endereco != null){

        elementoInputEnderecoPerfil.value = listaUsuarios[posicaoUsuarioLogado].endereco

    }else{
  
        elementoInputEnderecoPerfil.value = ''

    }

    {
        elementoLabelNomeLixosDesejadosUm.innerHTML = vetorLixosDesejados[0].nomeLixoDesejado
        j = 0

        if(vetorLixosDesejados[0].propTagsLixosDesejados[0] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosUm.innerHTML += 'Vidro'
        }

        if(vetorLixosDesejados[0].propTagsLixosDesejados[1] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosUm.innerHTML += 'Metal'

        }

        if(vetorLixosDesejados[0].propTagsLixosDesejados[2] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosUm.innerHTML += 'Eletrônico'

        }

        if(vetorLixosDesejados[0].propTagsLixosDesejados[3] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosUm.innerHTML += 'Plástico'

        }

        if(vetorLixosDesejados[0].propTagsLixosDesejados[4] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosUm.innerHTML += 'Orgânico'
        }

        if(vetorLixosDesejados[0].propTagsLixosDesejados[5] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosUm.innerHTML += 'Madeira'
        
        }
        elementoLabelNomeLixosDesejadosDois.innerHTML = vetorLixosDesejados[1].nomeLixoDesejado

        j = 0

        if(vetorLixosDesejados[1].propTagsLixosDesejados[0] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosDois.innerHTML += 'Vidro'
        }

        if(vetorLixosDesejados[1].propTagsLixosDesejados[1] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosDois.innerHTML += 'Metal'

        }

        if(vetorLixosDesejados[1].propTagsLixosDesejados[2] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosDois.innerHTML += 'Eletrônicos'

        }

        if(vetorLixosDesejados[1].propTagsLixosDesejados[3] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosDois.innerHTML += 'Plástico'

        }

        if(vetorLixosDesejados[1].propTagsLixosDesejados[4] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosDois.innerHTML += 'Orgânico'
        }

        if(vetorLixosDesejados[1].propTagsLixosDesejados[5] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosDois.innerHTML += 'Madeira'
        
        }
        elementoLabelNomeLixosDesejadosTres.innerHTML = vetorLixosDesejados[2].nomeLixoDesejado
        j = 0

        if(vetorLixosDesejados[2].propTagsLixosDesejados[0] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosTres.innerHTML += 'Vidro'
        }

        if(vetorLixosDesejados[2].propTagsLixosDesejados[1] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosTres.innerHTML += 'Metal'

        }

        if(vetorLixosDesejados[2].propTagsLixosDesejados[2] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosTres.innerHTML += 'Eletrônicos'

        }

        if(vetorLixosDesejados[2].propTagsLixosDesejados[3] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosTres.innerHTML += 'Plástico'

        }

        if(vetorLixosDesejados[2].propTagsLixosDesejados[4] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosTres.innerHTML += 'Orgânico'
        }

        if(vetorLixosDesejados[2].propTagsLixosDesejados[5] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosTres.innerHTML += 'Madeira'
        
        }
        elementoLabelNomeLixosDesejadosQuatro.innerHTML = vetorLixosDesejados[3].nomeLixoDesejado
        j = 0

        if(vetorLixosDesejados[3].propTagsLixosDesejados[0] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Vidro'
        }

        if(vetorLixosDesejados[3].propTagsLixosDesejados[1] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Metal'

        }

        if(vetorLixosDesejados[3].propTagsLixosDesejados[2] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Eletrônicos'

        }

        if(vetorLixosDesejados[3].propTagsLixosDesejados[3] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Plástico'

        }

        if(vetorLixosDesejados[3].propTagsLixosDesejados[4] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Orgânico'
        }

        if(vetorLixosDesejados[3].propTagsLixosDesejados[5] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Madeira'
        
        }
        elementoLabelNomeLixosDesejadosCinco.innerHTML = vetorLixosDesejados[4].nomeLixoDesejado
        j = 0

        if(vetorLixosDesejados[4].propTagsLixosDesejados[0] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Vidro'
        }

        if(vetorLixosDesejados[4].propTagsLixosDesejados[1] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Metal'

        }

        if(vetorLixosDesejados[4].propTagsLixosDesejados[2] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Eletrônicos'

        }

        if(vetorLixosDesejados[4].propTagsLixosDesejados[3] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Plástico'

        }

        if(vetorLixosDesejados[4].propTagsLixosDesejados[4] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Orgânico'
        }

        if(vetorLixosDesejados[4].propTagsLixosDesejados[5] == true){
            if (j > 0){
                elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
            }
            j++
            elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Madeira'
        
    }}

    
}

function VerificarAlterarDados(){

    
    if(elementoInputNomePerfil.value == '' || elementoInputEmailPerfil.value == '' || elementoInputTelefonePerfil.value == ''){
        
        
    }else{
        emailPerfilExistente = false
        for(i=0;i < listaUsuarios.length; i++){

            if(elementoInputEmailPerfil.value != listaUsuarios[i].email){

                console.log('Passou no teste de validação de perfil ' + i+1)

            }else if(posicaoUsuarioLogado == i){

                console.log('posição certa do usuário, tudo tranquilo')

            }else{

                emailPerfilExistente = true
                break

            }

        }

        if(emailPerfilExistente){


            elementoInputNomePerfil.value = listaUsuarios[posicaoUsuarioLogado].nome
            elementoInputEmailPerfil.value = listaUsuarios[posicaoUsuarioLogado].email
            elementoInputTelefonePerfil.value = listaUsuarios[posicaoUsuarioLogado].telefone

        }else{


            listaUsuarios[posicaoUsuarioLogado].nome = elementoInputNomePerfil.value
            listaUsuarios[posicaoUsuarioLogado].email = elementoInputEmailPerfil.value
            listaUsuarios[posicaoUsuarioLogado].telefone = elementoInputTelefonePerfil.value

            if(elementoInputEnderecoPerfil != null){

                listaUsuarios[posicaoUsuarioLogado].endereco = elementoInputEnderecoPerfil.value 
        
            }else{
          
                listaUsuarios[posicaoUsuarioLogado].endereco = ''
        
            }
            localStorage.setItem('cadastroUsuario', JSON.stringify(listaUsuarios))

        }

    }

}

function VerificarAlterarSenha(){

    if(elementoInputSenhaPerfil.value == '' || elementoInputNovaSenhaPerfil.value == ''|| elementoInputConfirmarSenhaPerfil.value == ''){


    }else if(elementoInputSenhaPerfil.value != listaUsuarios[posicaoUsuarioLogado].senha){

        
    }else if(elementoInputNovaSenhaPerfil.value != elementoInputConfirmarSenhaPerfil.value){
        

    }else{

        listaUsuarios[posicaoUsuarioLogado].senha = elementoInputNovaSenhaPerfil.value
        localStorage.setItem('cadastroUsuario', JSON.stringify(listaUsuarios))


    }

}

function Desconectar(){

    usuarioLogado = false
    posicaoUsuarioLogado = null


    localStorage.setItem('posicaoUsuario', JSON.stringify(posicaoUsuarioLogado))
    localStorage.setItem('usuarioLogado', JSON.stringify(usuarioLogado))

    window.location.href = 'login.html'


}

function VerificarDeletar(){

    if (elementoInputSenhaPerfil.value == '' || elementoInputConfirmarSenhaPerfil.value == ''){

        alert('Para deletar a conta, coloque sua senha atual e confirme ela para confirmar a exclusão')

    }else if (elementoInputSenhaPerfil.value != listaUsuarios[posicaoUsuarioLogado].senha){


    }else if (elementoInputSenhaPerfil.value != elementoInputConfirmarSenhaPerfil.value){


    }else{

        listaUsuarios.splice(posicaoUsuarioLogado, 1)
        
        localStorage.setItem('cadastroUsuario', JSON.stringify(listaUsuarios))

        usuarioLogado = false
        posicaoUsuarioLogado = null

        window.location.href = 'login.html'
    
        localStorage.setItem('posicaoUsuario', JSON.stringify(posicaoUsuarioLogado))
        localStorage.setItem('usuarioLogado', JSON.stringify(usuarioLogado))

    }

}

//? Fim das funções de Dados Pessoais

//? Início das funções de Lixos Desejados

function VerificarAdicionarLixo(){

    VerificarVetorLixoDesejado()
    console.log(elementoInputAdicionarLixo.value)

    console.log(Object.entries(objUsuario))

    switch (true){

        

        case elementoInputAdicionarLixo.value == '':
            
            break;
        case !tagsLixoDesejado.includes(true):
            
            break;

        case !elementoButtonRiscoTranquilo.classList.contains('riscoButtonsAtivados') && !elementoButtonRiscoMedio.classList.contains('riscoButtonsAtivados') && !elementoButtonRiscoMaior.classList.contains('riscoButtonsAtivados'):

            break;
        
        default:

            if(vetorLixosDesejados == null){
                
                vetorLixosDesejados = []
            }

            if(listaUsuarios == null){

                listaUsuarios = []
            }

            console.log(vetorLixosDesejados)

            console.log(`Tamanho da lista de vetor de lixo desejado: ${vetorLixosDesejados.length}`)

            if(vetorLixosDesejados.length >= 5){


            }else{

                objLixoDesejadoUsuario = {}

                objLixoDesejadoUsuario.nomeLixoDesejado = elementoInputAdicionarLixo.value
                console.log(elementoButtonRiscoTranquilo.classList.contains(true))
                
                switch (true){

                    case elementoButtonRiscoTranquilo.classList.contains('riscoButtonsAtivados'):

                        objLixoDesejadoUsuario.nivelPerigo = 'Tranquilo'

                        break;
                    case elementoButtonRiscoMedio.classList.contains('riscoButtonsAtivados'):
                        
                        objLixoDesejadoUsuario.nivelPerigo = 'Médio'
                        break;
                    case elementoButtonRiscoMaior.classList.contains('riscoButtonsAtivados'):
                        
                        objLixoDesejadoUsuario.nivelPerigo = 'Maior'
                        break;
                        

                }

                VerificarPosicaoHistoricoLixo()

                objLixoDesejadoUsuario.propTagsLixosDesejados = tagsLixoDesejado
                vetorLixosDesejados.push(objLixoDesejadoUsuario)
                objUsuario.propLixosDesejados = vetorLixosDesejados[posicaoUsuarioLogado]
                //listaUsuarios.push(objUsuario)
                
                localStorage.setItem('vetorLixosDesejados', JSON.stringify(vetorLixosDesejados))

                //listaUsuarios.push(objUsuario)
                localStorage.setItem('cadastroUsuario', JSON.stringify(listaUsuarios))
                }

                
            }
    }

    console.table(tagsLixoDesejado)



function TagUm(){

    
    elementoButtonTagUm.classList.toggle('tagAtivada')

    VerificarVetorLixoDesejado()

    if(tagsLixoDesejado[0] == true){

        tagsLixoDesejado.splice(0,1,false)
        

    }else if(j >= 3){

        
    elementoButtonTagUm.classList.remove('tagAtivada')

    }else{
        
        tagsLixoDesejado.splice(0,1,true)

    }

}

function TagDois(){


    elementoButtonTagDois.classList.toggle('tagAtivada')

    VerificarVetorLixoDesejado()

    if(tagsLixoDesejado[1] == true){

        tagsLixoDesejado.splice(1,1,false)
        
    }else if(j >= 3){
        

        elementoButtonTagDois.classList.remove('tagAtivada')
        
    }else{
        
        tagsLixoDesejado.splice(1,1,true)

    }

    
}

function TagTres(){


    elementoButtonTagTres.classList.toggle('tagAtivada')

    VerificarVetorLixoDesejado()

    if(tagsLixoDesejado[2] == true){

        tagsLixoDesejado.splice(2,1,false)
        
    }else if(j >= 3){
        
        elementoButtonTagTres.classList.remove('tagAtivada')
        
    }else{
        
        tagsLixoDesejado.splice(2,1,true)

    }

}

function TagQuatro(){

    elementoButtonTagQuatro.classList.toggle('tagAtivada')

    VerificarVetorLixoDesejado()

    if(tagsLixoDesejado[3] == true){

        tagsLixoDesejado.splice(3,1,false)
        
    }else if(j >= 3){
        
        elementoButtonTagQuatro.classList.remove('tagAtivada')
    }else{
        
        tagsLixoDesejado.splice(3,1,true)

    }
}

function TagCinco(){

    
    elementoButtonTagCinco.classList.toggle('tagAtivada')

    VerificarVetorLixoDesejado()

    if(tagsLixoDesejado[4] == true){

        tagsLixoDesejado.splice(4,1,false)
        
    }else if(j >= 3){
        
        elementoButtonTagCinco.classList.remove('tagAtivada')
        
    }else{
        
        tagsLixoDesejado.splice(4,1,true)

    }

}

function TagSeis(){


    
    elementoButtonTagSeis.classList.toggle('tagAtivada')

    VerificarVetorLixoDesejado()

    if(tagsLixoDesejado[5] == true){

        tagsLixoDesejado.splice(5,1,false)
        
    }else if(j >= 3){
        

        elementoButtonTagSeis.classList.remove('tagAtivada')

        
    }else{
        
        tagsLixoDesejado.splice(5,1,true)

    }
    
}

function VerificarVetorLixoDesejado(){

    if(tagsLixoDesejado == null){

        tagsLixoDesejado = [false,false,false,false,false,false]

    }

    j = 0

    for(i=0;i<tagsLixoDesejado.length;i++){

        

        if(tagsLixoDesejado[i] == true){

            j++

            console.log(j)
        }

    }

}





function RiscoTranquilo(){
    
    
    elementoButtonRiscoMedio.classList.remove('riscoButtonsAtivados')
    elementoButtonRiscoMaior.classList.remove('riscoButtonsAtivados')
    elementoButtonRiscoTranquilo.classList.toggle('riscoButtonsAtivados')

}


function RiscoMedio(){
    
    
    elementoButtonRiscoTranquilo.classList.remove('riscoButtonsAtivados')
    elementoButtonRiscoMaior.classList.remove('riscoButtonsAtivados')
    elementoButtonRiscoMedio.classList.toggle('riscoButtonsAtivados')
}


function RiscoMaior(){
    
    
    elementoButtonRiscoTranquilo.classList.remove('riscoButtonsAtivados')
    elementoButtonRiscoMedio.classList.remove('riscoButtonsAtivados')
    elementoButtonRiscoMaior.classList.toggle('riscoButtonsAtivados')
    
}


function VerificarPosicaoHistoricoLixo(){
    
    console.log(elementoInputAdicionarLixo.value)

    j = 0
    switch (true){

        case vetorLixosDesejados.length == 0:
            
            elementoLabelNomeLixosDesejadosUm.innerHTML = elementoInputAdicionarLixo.value
            elementoLabelTagsLixosDesejadosUm.innerHTML = '' 

            if(tagsLixoDesejado[0] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosUm.innerHTML += 'Vidro'
            }

            if(tagsLixoDesejado[1] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosUm.innerHTML += 'Metal'

            }

            if(tagsLixoDesejado[2] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosUm.innerHTML += 'Eletrônicos'

            }

            if(tagsLixoDesejado[3] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosUm.innerHTML += 'Plástico'

            }

            if(tagsLixoDesejado[4] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosUm.innerHTML += 'Orgânico'
            }

            if(tagsLixoDesejado[5] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosUm.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosUm.innerHTML += 'Madeira'
            
            }
            break
        case vetorLixosDesejados.length == 1:
            
            elementoLabelNomeLixosDesejadosDois.innerHTML = elementoInputAdicionarLixo.value
            elementoLabelTagsLixosDesejadosDois.innerHTML = '' 

            if(tagsLixoDesejado[0] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosDois.innerHTML += 'Vidro'
            }

            if(tagsLixoDesejado[1] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosDois.innerHTML += 'Metal'

            }

            if(tagsLixoDesejado[2] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosDois.innerHTML += 'Eletrônicos'

            }

            if(tagsLixoDesejado[3] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosDois.innerHTML += 'Plástico'

            }

            if(tagsLixoDesejado[4] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosDois.innerHTML += 'Orgânico'
            }

            if(tagsLixoDesejado[5] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosDois.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosDois.innerHTML += 'Madeira'
            
            }
            break
        case vetorLixosDesejados.length == 2:
            
            elementoLabelNomeLixosDesejadosTres.innerHTML = elementoInputAdicionarLixo.value
            elementoLabelTagsLixosDesejadosTres.innerHTML = '' 

            if(tagsLixoDesejado[0] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosTres.innerHTML += 'Vidro'
            }

            if(tagsLixoDesejado[1] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosTres.innerHTML += 'Metal'

            }

            if(tagsLixoDesejado[2] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosTres.innerHTML += 'Eletrônicos'

            }

            if(tagsLixoDesejado[3] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosTres.innerHTML += 'Plástico'

            }

            if(tagsLixoDesejado[4] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosTres.innerHTML += 'Orgânico'
            }

            if(tagsLixoDesejado[5] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosTres.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosTres.innerHTML += 'Madeira'
            
            }
            break
        case vetorLixosDesejados.length == 3:
            
            elementoLabelNomeLixosDesejadosQuatro.innerHTML = elementoInputAdicionarLixo.value
            elementoLabelTagsLixosDesejadosQuatro.innerHTML = '' 

            if(tagsLixoDesejado[0] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Vidro'
            }

            if(tagsLixoDesejado[1] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Metal'

            }

            if(tagsLixoDesejado[2] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Eletrônicos'

            }

            if(tagsLixoDesejado[3] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Plástico'

            }

            if(tagsLixoDesejado[4] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Orgânico'
            }

            if(tagsLixoDesejado[5] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosQuatro.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosQuatro.innerHTML += 'Madeira'
            
            }
            break
        case vetorLixosDesejados.length == 4:
            
            elementoLabelNomeLixosDesejadosCinco.innerHTML = elementoInputAdicionarLixo.value
            elementoLabelTagsLixosDesejadosCinco.innerHTML = '' 

            if(tagsLixoDesejado[0] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Vidro'
            }

            if(tagsLixoDesejado[1] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Metal'

            }

            if(tagsLixoDesejado[2] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Eletrônicos'

            }

            if(tagsLixoDesejado[3] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Plástico'

            }

            if(tagsLixoDesejado[4] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Orgânico'
            }

            if(tagsLixoDesejado[5] == true){
                if (j > 0){
                    elementoLabelTagsLixosDesejadosCinco.innerHTML +=', '
                }
                j++
                elementoLabelTagsLixosDesejadosCinco.innerHTML += 'Madeira'
            
            }
            break
        
    
}
}



function DeletarLixosDesejados(){

    console.log('antes de deletar '+ vetorLixosDesejados)
    if(elementoCheckboxCinco.checked == true){

        vetorLixosDesejados.splice(4,1)
        elementoLabelNomeLixosDesejadosCinco.innerHTML = ''
        elementoLabelTagsLixosDesejadosCinco.innerHTML = ''
        
    console.log('deletei o quinto '+ vetorLixosDesejados)
    }

    if(elementoCheckboxQuatro.checked == true){

        vetorLixosDesejados.splice(3,1)
        elementoLabelNomeLixosDesejadosQuatro.innerHTML = ''
        elementoLabelTagsLixosDesejadosQuatro.innerHTML = ''
        console.log('deletei o quarto '+ vetorLixosDesejados)
    }

    if(elementoCheckboxTres.checked == true){

        vetorLixosDesejados.splice(2,1)
        elementoLabelNomeLixosDesejadosTres.innerHTML = ''
        elementoLabelTagsLixosDesejadosTres.innerHTML = ''
        console.log('deletei o terceiro '+ vetorLixosDesejados)
    }

    if(elementoCheckboxDois.checked == true){

        vetorLixosDesejados.splice(1,1)
        elementoLabelNomeLixosDesejadosDois.innerHTML = ''
        elementoLabelTagsLixosDesejadosDois.innerHTML = ''
        console.log('deletei o segundo '+ vetorLixosDesejados)
    }

    if(elementoCheckboxUm.checked == true){

        vetorLixosDesejados.splice(0,1)
        elementoLabelNomeLixosDesejadosUm.innerHTML = ''
        elementoLabelTagsLixosDesejadosUm.innerHTML = ''
        console.log('deletei o primeiro '+ vetorLixosDesejados)
    }

    objLixoDesejadoUsuario.propTagsLixosDesejados = tagsLixoDesejado
    localStorage.setItem('vetorLixosDesejados', JSON.stringify(vetorLixosDesejados))

}

function Pesquisar() {

    document.getElementById("imagemMapa").src="Untitled69_20240730214215.png";
    
    
    elementoDivDireitaMeioMainPag.classList.add('divDireitaMeioAtivada')
    elementoDivDireitaBaixo.classList.add('divDireitaMeioAtivadoDois')
    
    } 


function ValidarCPFCNPJ(){

    fisicoJuridicoInvalido = false
    separarNumerosFisicoJuridico = elementoInputFisicoJuridicoCadastro.value.split('')

    console.log(separarNumerosFisicoJuridico)

    if(separarNumerosFisicoJuridico.length == 11 || separarNumerosFisicoJuridico.length == 14){

        console.log(separarNumerosFisicoJuridico.length)
        somaFisicoJuridico = 0

        if(contaPessoal){

            console.log('teste')

            j = 10

            for(i=0; i < 9;i++){

                
                multiplicacaoFisicoJuridico = separarNumerosFisicoJuridico[i] * j
                somaFisicoJuridico += multiplicacaoFisicoJuridico

                j--

                console.log('resultado da soma: '+somaFisicoJuridico)
            }

            resultadoFisicoJuridico = somaFisicoJuridico % 11
            resultadoFisicoJuridico = 11 - resultadoFisicoJuridico

            if (resultadoFisicoJuridico > 9){

                resultadoFisicoJuridico = 0
            }

            console.log('esse numéro é o 10 digito do cpf: ' + resultadoFisicoJuridico)

            if(resultadoFisicoJuridico == separarNumerosFisicoJuridico[9]){

                j = 11
                somaFisicoJuridico = 0

                for(i=0; i < 10;i++){

                    
                    multiplicacaoFisicoJuridico = separarNumerosFisicoJuridico[i] * j
                    somaFisicoJuridico += multiplicacaoFisicoJuridico

                    j--

                    console.log('resultado da soma 2: '+somaFisicoJuridico)
                }

                resultadoFisicoJuridico = somaFisicoJuridico % 11
                resultadoFisicoJuridico = 11 - resultadoFisicoJuridico

                if(resultadoFisicoJuridico > 9){

                    resultadoFisicoJuridico = 0
                }

                
                console.log('esse numéro é o 11 digito do cpf: ' + resultadoFisicoJuridico)

                if(resultadoFisicoJuridico == separarNumerosFisicoJuridico[10]){


                }else{

                    //todo tirar alert e colocar no html como label

                    VerificarCadastro()
                    elementoAvisoFisicoJuridico.innerHTML = `O CPF/CNPJ é invalido`

                    fisicoJuridicoInvalido = true
                }
            }else{

                //todo tirar alert e colocar no html como label
                fisicoJuridicoInvalido = true
            }


        }else if(contaEmpresarial){

            j = 2

            for(i=11; i > -1; i--){

                console.log (`Numero a ser multiplicado ${separarNumerosFisicoJuridico[i]}\nNumero a Multiplicar ${j}`)
                multiplicacaoFisicoJuridico = separarNumerosFisicoJuridico[i] * j
                somaFisicoJuridico += multiplicacaoFisicoJuridico

                j++

                if (j > 9){

                    j = 2
                }

                console.log('resultado da soma: '+somaFisicoJuridico)
            }

            resultadoFisicoJuridico = somaFisicoJuridico % 11
            resultadoFisicoJuridico = 11 - resultadoFisicoJuridico

            if (resultadoFisicoJuridico > 9){

                resultadoFisicoJuridico = 0
            }

            console.log('esse numéro é o 13 do CNPJ: ' + resultadoFisicoJuridico)

            if(resultadoFisicoJuridico == separarNumerosFisicoJuridico[12]){

                j = 2
                somaFisicoJuridico = 0

                for(i=12; i > -1;i--){

                    console.log (`Numero a ser multiplicado ${separarNumerosFisicoJuridico[i]}\nNumero a Multiplicar ${j}`)

                    multiplicacaoFisicoJuridico = separarNumerosFisicoJuridico[i] * j
                    somaFisicoJuridico += multiplicacaoFisicoJuridico

                    j++

                    if(j > 9){

                        j = 2

                    }

                    console.log('resultado da soma 2: '+somaFisicoJuridico)
                }

                resultadoFisicoJuridico = somaFisicoJuridico % 11
                resultadoFisicoJuridico = 11 - resultadoFisicoJuridico

                if(resultadoFisicoJuridico > 9){

                    resultadoFisicoJuridico = 0
                }

                
                console.log('esse numéro é o 14 digito do CNPJ: ' + resultadoFisicoJuridico)

                if(resultadoFisicoJuridico == separarNumerosFisicoJuridico[13]){


                }else{

                    //todo tirar alert e colocar no html como label
                    fisicoJuridicoInvalido = true
                }
            }else{

                //todo tirar alert e colocar no html como label
                fisicoJuridicoInvalido = true
            }


        }else{

            //todo tirar alert e colocar no html como label

        }



    }else{

        //todo tirar alert e colocar no html como label
        fisicoJuridicoInvalido = true


    }


}

function IrparaLogin() {


    window.location.href = 'login.html'


}


function IrparaCadastro() {


    window.location.href = 'cadastro.html'


}

function IrparaPerfil(){

    window.location.href = 'perfilUsuario.html'


}

function PaginaPrincipal() {


    window.location.href = 'paginaPrincipal.html'

}



if(usuarioLogado == false){


    elementoDivDireitaTopoPerfil.classList.add('divTopoButtonsPerfilDesativado')

    elementoDivDireitaTopo.classList.add('divTopoButtonsAtivado')
    

}else{


    elementoDivDireitaTopoPerfil.classList.remove('divTopoButtonsPerfilDesativado')
    elementoDivDireitaTopo.classList.remove('divTopoButtonsAtivado')



}