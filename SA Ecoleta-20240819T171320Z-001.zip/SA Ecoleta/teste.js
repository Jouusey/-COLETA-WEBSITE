let elementoDivLetras = document.getElementById('letras')
let elementoDivNumeros = document.getElementById('numeros')

function Letras(){

    elementoDivLetras.style.display = 'block'
    elementoDivNumeros.style.display = 'none'

}

function Numeros(){

    elementoDivLetras.style.display = 'none'
    elementoDivNumeros.style.display = 'block'


}